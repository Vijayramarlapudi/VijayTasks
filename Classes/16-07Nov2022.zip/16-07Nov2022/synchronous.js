function f1(){
    console.log('I am first function')
}

function f2(){
    console.log('I am second function')
}

f1();
f2();
