function f1(param1,param2){
    console.log(param1)
    console.log(param2)
    console.log(arguments)
}

f1(10,3,5);