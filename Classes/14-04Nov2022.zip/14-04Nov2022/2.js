function getScore(){
    // Some API will be called
    // returning some data
    return "151/3";
}

var output = getScore();
console.log(output)