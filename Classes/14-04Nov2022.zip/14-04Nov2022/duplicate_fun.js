function f1(){
    console.log("I am original function")
}

function f1(param1,param2){
    console.log("I am duplicate function")
}

f1();

