function validate_Credentials(uid,pwd){
    if(uid=="ravi" && pwd=='r123'){
        console.log('valid')
    }else{
        console.log('invalid')
    }
}

validate_Credentials('ravi','r123');