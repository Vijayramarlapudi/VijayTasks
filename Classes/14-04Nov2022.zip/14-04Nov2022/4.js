function f4(){
    console.log('without params and without return type')
}

f4();