function f1(){
    console.log("I am basic function!")
}

f1();