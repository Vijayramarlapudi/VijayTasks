// String Interpolation

// console.log(
//     `
//         x1 
//                     x2
//     `
// )


var str = `
line1

                      line2 

line3 

                                    line4

`;

console.log(str)