import {name,age} from './modules/person.js'
console.log(name,age)