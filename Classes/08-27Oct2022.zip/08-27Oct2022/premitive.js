// var var_name="data"

// Number
var age=22;

var rating=3.5;

var counter=1;

var price=289654;

var mNo="8985865865";

console.log(typeof age)
console.log(typeof rating)
console.log(typeof counter)
console.log(typeof price)
console.log(typeof mNo)

// String
var uname="test123";

var msg="hello world";

var address="test address"


// Boolean - always returns true/false

var isProcessDone=true;

var isProcessDone=false;