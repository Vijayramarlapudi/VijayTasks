var users=['ravi','kiran','nanda']

// Access whole array
console.log(users)

// Access an element based on the provided index value/position
console.log(users[1])

// Get total no of users
console.log(users.length)

// task
// try to have multiple datatypes of data in arrays