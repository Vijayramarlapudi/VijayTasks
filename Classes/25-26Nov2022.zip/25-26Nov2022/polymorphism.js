// Polymorphism:
// It is the ability of an entity to provide multipe functionalities
// based on different inputs is known as Polymorphism.
// in Ts, we implement Polymorphism using method overloading and method overriding.
// Method Overloading: It is the ability of a method to provide different
// functionalities based on different inputs.
// rules:
// 1. method name must be same
// 2. there should be a difference in number of parameters or type of parameters.
