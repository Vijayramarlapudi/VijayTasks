// Method Overiding: 

class Login{
    authenticate(mobile_number:number, password:string);
    authenticate(email:string, password:string);

    // method overloading
    authenticate(input1:string | number, input2:string){
        if(typeof input1=="number"){
            console.log("logged in with mobile number");
            return;
        }
        if(typeof input1=="string"){
            console.log("logged in with email Id");
        }
    }
}   

var login=new Login();
login.authenticate('venu@gmail.com','venu')