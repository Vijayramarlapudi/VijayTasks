// Constructor:
// If we want to create an object, then we have to use constructor.


// In a class, if we don't have a constructor, then default constructor will be 
// provided by typescript.

// ex:

class A1{


}



// caling super class constructor using "super()"
class A{
    constructor(){
        console.log("Constructor A");
    }
}

class B extends A{
    constructor(){
        super()
        console.log("Constructor B")
    }
}

var b=new B();

// In the above example, default constructor is provided by TS.



class Employeee{
    name;
    address;
    company;

    constructor(name, address, company){
        this.name=name;
        this.address=address;
        this.company=company;
    }
}

var emp12=new Employeee("ravi", "hyd", "abc")
var emp123 = new Employeee('kiran','sec',"bbc")
console.log(emp12)
console.log(emp123)


class Customer{
    name;
    accno;
    balance;
    aadhar;
    mobilenumber;

    constructor(name,accno,balance,aadhar,mobilenumber){
        this.name=name;
        this.accno=accno;
        this.balance=balance;
        this.aadhar=aadhar;
        this.mobilenumber=mobilenumber;
    }
}

var cust1=new Customer("venu","12345",123156,123565565656,8985865865);

console.log(cust1)



