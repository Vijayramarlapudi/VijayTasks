// iterators
// for of
// for of, we can use it to deal with array
// for(let x of []){
// }
// for in
// for in, we can use it to deal with Object
// for(let x in {}){
// }
