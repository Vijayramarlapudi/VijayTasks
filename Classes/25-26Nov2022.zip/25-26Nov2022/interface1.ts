interface InterfaceName{
    f1();
    f2();
}

class x implements InterfaceName {
    f1(){

    }
    f2() {
        
    }
}



var xyz:InterfaceName=new x;

xyz.f1();
xyz.f2();


interface Panel{
    currentState:boolean;
    turnOnOff();
    currentTemp:number;
    minTemp:number;
    maxTem:number;
    incTemp();
    decTemp();
    swingMode();
    // timer();
    // sleep(time:number)
}

class MotherBoard implements Panel{
    currentState=false;
    currentTemp=21;
    minTemp=16;
    maxTem=32;

    // abstract timer();
    // abstract sleep(time:number);

    turnOnOff(){
        if(this.currentState==false){
            this.currentState = true;
            console.log("Remote On")
        }
        else{
            this.currentState=false;
            console.log("Remote Off")
        }
    }

    incTemp(){
        if(this.currentState==true){
            if(this.currentTemp>this.minTemp && this.currentTemp<this.maxTem){
                this.currentTemp++;
                console.log('Current Temp:',this.currentTemp)
            }
        }
        else{
            console.log('Turn on Remote')
        }
    }

    decTemp(){
        if(this.currentState==true){
            if(this.currentTemp>this.minTemp && this.currentTemp<this.maxTem){
                this.currentTemp--;
                console.log('Current Temp:',this.currentTemp)
            }
        }
        else{
            console.log('Turn on Remote')
        }
    }

    swingMode(){

    }

}

var panel:Panel= new MotherBoard();
panel.turnOnOff();
panel.incTemp();
panel.incTemp();
panel.decTemp();