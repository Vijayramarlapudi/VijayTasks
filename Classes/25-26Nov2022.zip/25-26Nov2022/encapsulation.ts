// Encapsulation:
// it is the process of binding the data and its code together
// into a single unit.

// ex: class