// Abstraction:

// It is the process of providing only required details.

// We implement Abstraction using interfaces and abstract classes.

// Interface:

// An interface is a collection of uninitialized variables and unimplemented methods.

// syntax:

// interface InterfaceName{
//     x;
//     m1();
//     m2();
// }

// key points:
// * An interface can have only uninitialized variables and unimplemented methods.
// * For an interface we can not create object.
// * An interface need to be implemented by a class using implements keyword.
// * If a class implements an interface, it should provide the implementation for 
//   all the methods of an interface.