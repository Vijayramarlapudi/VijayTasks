// // Super Class
// class Calc{
//     add(number1:number, number2:number){
//         console.log(number1+number2)
//     }

//     sub(number1:number, number2:number){
//         console.log(number1-number2)
//     }
// }

// var calc = new Calc();
// calc.add(10,20);


// // Sub class
// // Inheriting super class to sub class using "extends" keyword
// class ScientifiCalc extends Calc{
//     square(number:number){
//         console.log(number*number)
//     }
// }

// var scalc=new ScientifiCalc();
// scalc.square(10);
// scalc.add(10,1);
// scalc.sub(10,1)



class Login{
    authenticate(username:string,passwrod:string){
        if(username=="venu" && passwrod=="venu123"){
            console.log("Logged in!");
            return true;
        }
        else{
            console.log("Login failure");
            return false;
        }
    }
}

class Home extends Login{

}

var home1=new Home();

var result= home1.authenticate("venu","venu1234")

console.log(result);


/////////////////////////////////////

class Register{
    submit(mno:number,password:string,emailId:string);
    submit(username:string,password:string,emailId:string);

    submit(input1:number | string, input2: string, input3:string){
        if(typeof input1=="number"){
            console.log("logged in with mobile number!")
        }
        if(typeof input1=="string"){
            console.log("logged in with username!")
        }
    }
}

var register=new Register();
register.submit(7207838143,'venu','venu@123')
