var x = 123;
x = "121";
var abc = /** @class */ (function () {
    function abc() {
    }
    return abc;
}());
var xyz = new abc;
