// modules:
// A module is same as namespace with a small difference, In modules,
// we don't create a module, instead the filename becomes the module name.

// we use import and export keywords to access the resources across
// multiple files.

export class Login{
    loginByMno() {
        console.log('by mno');
    }
    LoginByUPWD () {
        console.log('by upwd');
    }
}
export const A=1000;