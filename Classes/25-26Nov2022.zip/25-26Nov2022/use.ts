import { Login, A } from "./user";

console.log(A);

var log = new Login();

log.loginByMno();
log.LoginByUPWD();