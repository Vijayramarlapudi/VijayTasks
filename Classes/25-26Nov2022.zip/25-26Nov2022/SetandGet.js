class Employee{
    name;

    set ename(name){
        if(name == null || name == ""){
            console.log('name can not be empty')
        }
        this.name=name;
    }

    get ename(){
        return this.name
    }
}

var emp= new Employee();
emp.ename="hello";
console.log(emp);