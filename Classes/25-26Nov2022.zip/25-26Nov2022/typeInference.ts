var x:number=123
x="121"

class abc{

}

var xyz=new abc;