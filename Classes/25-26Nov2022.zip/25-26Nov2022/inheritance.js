// // Super Class
// class Calc{
//     add(number1:number, number2:number){
//         console.log(number1+number2)
//     }
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
//     sub(number1:number, number2:number){
//         console.log(number1-number2)
//     }
// }
// var calc = new Calc();
// calc.add(10,20);
// // Sub class
// // Inheriting super class to sub class using "extends" keyword
// class ScientifiCalc extends Calc{
//     square(number:number){
//         console.log(number*number)
//     }
// }
// var scalc=new ScientifiCalc();
// scalc.square(10);
// scalc.add(10,1);
// scalc.sub(10,1)
var Login = /** @class */ (function () {
    function Login() {
    }
    Login.prototype.authenticate = function (username, passwrod) {
        if (username == "venu" && passwrod == "venu123") {
            console.log("Logged in!");
            return true;
        }
        else {
            console.log("Login failure");
            return false;
        }
    };
    return Login;
}());
var Home = /** @class */ (function (_super) {
    __extends(Home, _super);
    function Home() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return Home;
}(Login));
var home1 = new Home();
var result = home1.authenticate("venu", "venu1234");
console.log(result);
