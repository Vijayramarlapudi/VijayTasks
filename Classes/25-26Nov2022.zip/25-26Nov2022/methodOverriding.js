// Method Overiding:
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var A1 = /** @class */ (function () {
    function A1() {
    }
    A1.prototype.m1 = function () {
        console.log("m1 in A1");
    };
    A1.prototype.m2 = function () {
        console.log("m2 in A1");
    };
    return A1;
}());
var A2 = /** @class */ (function (_super) {
    __extends(A2, _super);
    function A2() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    // method overriding
    A2.prototype.m2 = function () {
        console.log("m2 in A2");
    };
    return A2;
}(A1));
var a2 = new A2();
a2.m1();
a2.m2();
