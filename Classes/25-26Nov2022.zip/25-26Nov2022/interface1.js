var x = /** @class */ (function () {
    function x() {
    }
    x.prototype.f1 = function () {
    };
    x.prototype.f2 = function () {
    };
    return x;
}());
var xyz = new x;
xyz.f1();
xyz.f2();
var MotherBoard = /** @class */ (function () {
    function MotherBoard() {
        this.currentState = false;
        this.currentTemp = 21;
        this.minTemp = 16;
        this.maxTem = 32;
    }
    // abstract timer();
    // abstract sleep(time:number);
    MotherBoard.prototype.turnOnOff = function () {
        if (this.currentState == false) {
            this.currentState = true;
            console.log("Remote On");
        }
        else {
            this.currentState = false;
            console.log("Remote Off");
        }
    };
    MotherBoard.prototype.incTemp = function () {
        if (this.currentState == true) {
            if (this.currentTemp > this.minTemp && this.currentTemp < this.maxTem) {
                this.currentTemp++;
                console.log('Current Temp:', this.currentTemp);
            }
        }
        else {
            console.log('Turn on Remote');
        }
    };
    MotherBoard.prototype.decTemp = function () {
        if (this.currentState == true) {
            if (this.currentTemp > this.minTemp && this.currentTemp < this.maxTem) {
                this.currentTemp--;
                console.log('Current Temp:', this.currentTemp);
            }
        }
        else {
            console.log('Turn on Remote');
        }
    };
    MotherBoard.prototype.swingMode = function () {
    };
    return MotherBoard;
}());
var panel = new MotherBoard();
panel.turnOnOff();
panel.incTemp();
panel.incTemp();
panel.decTemp();
