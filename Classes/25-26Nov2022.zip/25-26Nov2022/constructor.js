// Constructor:
// If we want to create an object, then we have to use constructor.
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
// In a class, if we don't have a constructor, then default constructor will be 
// provided by typescript.
// ex:
var A1 = /** @class */ (function () {
    function A1() {
    }
    return A1;
}());
// caling super class constructor using "super()"
var A = /** @class */ (function () {
    function A() {
        console.log("Constructor A");
    }
    return A;
}());
var B = /** @class */ (function (_super) {
    __extends(B, _super);
    function B() {
        var _this = _super.call(this) || this;
        console.log("Constructor B");
        return _this;
    }
    return B;
}(A));
var b = new B();
// In the above example, default constructor is provided by TS.
var Employeee = /** @class */ (function () {
    function Employeee(name, address, company) {
        this.name = name;
        this.address = address;
        this.company = company;
    }
    return Employeee;
}());
var emp12 = new Employeee("ravi", "hyd", "abc");
var emp123 = new Employeee('kiran', 'sec', "bbc");
console.log(emp12);
console.log(emp123);
var Customer = /** @class */ (function () {
    function Customer(name, accno, balance, aadhar, mobilenumber) {
        this.name = name;
        this.accno = accno;
        this.balance = balance;
        this.aadhar = aadhar;
        this.mobilenumber = mobilenumber;
    }
    return Customer;
}());
var cust1 = new Customer("venu", "12345", 123156, 123565565656, 8985865865);
console.log(cust1);
