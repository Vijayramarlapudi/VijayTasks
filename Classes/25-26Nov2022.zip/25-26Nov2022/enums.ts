// Enum is used to group a set of constants into a single unit.


// Syntax:

// enum enumName{
//     
// }

const x = 100;
const result = true;
const url = "www.google.com"

enum settings{
    x = 100,
    result = "true",
    url = "www.google.com"
}

console.log(settings)
console.log(settings.url)


enum Config{
    PORT=1023,
    ID=109,
    ACCNO=123,
    BUILD=988
}

console.log(Config.PORT)