var user;
(function (user) {
    var Login = /** @class */ (function () {
        function Login() {
        }
        Login.prototype.authenticate = function () {
            console.log("authenticate");
        };
        return Login;
    }());
    user.Login = Login;
    user.x = 1000;
    function f1() {
        console.log("f1 called");
    }
    user.f1 = f1;
})(user || (user = {}));
new user.Login().authenticate();
console.log(user.x);
