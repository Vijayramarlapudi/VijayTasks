type n=number;
var mobileNumber:n;


type b=boolean;
var xyz:b = true;