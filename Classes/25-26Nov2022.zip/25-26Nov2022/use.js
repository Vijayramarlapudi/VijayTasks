"use strict";
exports.__esModule = true;
var user_1 = require("./user");
console.log(user_1.A);
var log = new user_1.Login();
log.loginByMno();
log.LoginByUPWD();
