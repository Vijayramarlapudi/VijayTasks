"use strict";
exports.__esModule = true;
exports.A = exports.Login = void 0;
var Login = /** @class */ (function () {
    function Login() {
    }
    Login.prototype.loginByMno = function () {
        console.log('by mno');
    };
    Login.prototype.LoginByUPWD = function () {
        console.log('by upwd');
    };
    return Login;
}());
exports.Login = Login;
exports.A = 1000;
