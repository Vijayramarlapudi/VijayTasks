// Enum is used to group a set of constants into a single unit.
// Syntax:
// enum enumName{
//     
// }
var x = 100;
var result = true;
var url = "www.google.com";
var settings;
(function (settings) {
    settings[settings["x"] = 100] = "x";
    settings["result"] = "true";
    settings["url"] = "www.google.com";
})(settings || (settings = {}));
console.log(settings);
console.log(settings.url);
var Config;
(function (Config) {
    Config[Config["PORT"] = 1023] = "PORT";
    Config[Config["ID"] = 109] = "ID";
    Config[Config["ACCNO"] = 123] = "ACCNO";
    Config[Config["BUILD"] = 988] = "BUILD";
})(Config || (Config = {}));
console.log(Config.PORT);
