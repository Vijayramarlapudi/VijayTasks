namespace user{
    export class Login{
        authenticate(){
            console.log("authenticate");
        }
    }
    export interface A{
        a;
    }
    export var x=1000;
    export function f1() {
        console.log("f1 called");
    }
}
new user.Login().authenticate();
console.log(user.x);