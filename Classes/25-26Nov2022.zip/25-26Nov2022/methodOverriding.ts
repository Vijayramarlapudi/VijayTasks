// Method Overiding:

class A1{
    m1(){
        console.log("m1 in A1")
    }

    m2(){
        console.log("m2 in A1")
    }
}

class A2 extends A1{
    // method overriding
    m2(){
        console.log("m2 in A2")
    }
}

var a2=new A2();

a2.m1();
a2.m2();