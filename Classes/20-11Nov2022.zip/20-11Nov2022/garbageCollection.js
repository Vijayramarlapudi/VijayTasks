// Garbage Collection:

var a={
    name:'ravi',
    address:"hyderabad"
}

console.log(a);

a=null; //garbage collection

console.log(a)