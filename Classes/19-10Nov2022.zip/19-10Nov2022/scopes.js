var global = 'this is global variable';

function f1(){

    local = 'this is local variable'

}
