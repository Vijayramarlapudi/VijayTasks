var tvRemote={
    brand:'LG',
    color:'Black',
    price:'2000',
    initialState:false,
    currentChannel:1,
    maxChannel:10,
    minChannel:1
}


tvRemote.initialState=true;

console.log(tvRemote)

