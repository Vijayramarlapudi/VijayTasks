// Premitive Type Ex
// const a=100;
// a++; // Not Possible
// console.log(a);

// Non Premitive Type Ex
// a value can be added to non premitive types but can not be reassigned
const aa = [1,2,3];
aa.push(100); //Possible
console.log(aa)

aa=[]  //Not Possible
console.log(aa);