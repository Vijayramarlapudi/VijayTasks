// for of:
    // can be used to loop through arrays.

    function f1(){
        const array1 = ['a', 'b', 'c'];

        // for(let i=0; i<array1.length;i++){
        //     console.log(array1[i])
        // }

        for (let element of array1) {
            console.log(element);
        }
    }

    f1();











    // const array1 = ['a', 'b', 'c'];

    // for (const element of array1) {
    // console.log(element);
    // }