// while: can be used to check the condition
// as long as condition satisified loop will be run.

// syntax:


// while(test-condition){

//     code
// }

// i=0;
// while(i<10){
//     console.log(i)
//     i++;
// }

var users=["ravi","kiran","rajesh","ravan","ram"];

var index=0;

while(index < users.length){
    console.log(users[index]);
    index++;
}