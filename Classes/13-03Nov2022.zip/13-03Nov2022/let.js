
// let: is used to create a blocked level variable.

// constant: we cannot assign a new value to a constant.
    

// function f1(){
//     let x=0;
//     for(i=0;i<10;i++){
        
//         x += i
//         console.log('x',x)
//     }

// }

// f1();
// console.log(x)



