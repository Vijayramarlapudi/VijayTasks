// cotinue - will skip an iteration

for(var i=0;i<10;i++){
    if(i!==2){
        continue; //terminates the iteration
    }
    console.log(i)
}