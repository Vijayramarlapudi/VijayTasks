var user;
user = "venu";
user = "101"; //should not store any value other than string
console.log(user);
// number
var a = 100;
// boolean
var isDone = false;
// string
var username = "ravi";
// any
var data;
data = 100;
data = "hello";
data = false;
console.log(data);
// array
var users = ["ravi", "kiran"];
console.log(users);
// tuple
var d;
d = ["hello", 123];
console.log(d);
// Object
var x = {
    a: 100,
    b: 200
};
console.log(x.a);
console.log(x.b);
console.log(x);
