var user:string;
user="venu";
user="101"; //should not store any value other than string

console.log(user);


// number
var a:number=100;


// boolean
var isDone:boolean=false;


// string
var username:string="ravi";


// any
var data:any;

data=100;
data="hello";
data=false;
console.log(data)


// array
var users:string[] = ["ravi","kiran"]
console.log(users)


// tuple
var d:[string,number];
d=["hello",123]
console.log(d)


// Object
var x={
    a:100,
    b:200
}

console.log(x.a)
console.log(x.b)
console.log(x)