function f1() {
    if (true) {
        var a = 100;
        console.log(a + 20);
    }
    // console.log(a)
}
f1();
// Primitive types
// const a=100;
// a=200;
// console.log(a)
// Non Primitive types
// const arr=[1,3,4]
// arr.push(100);
// console.log(arr)
