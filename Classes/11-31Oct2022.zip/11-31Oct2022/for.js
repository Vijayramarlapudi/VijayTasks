// function for_ex(){
//     var unames=5;

//     for(i=1;i<=unames;i++){
//         console.log(i)
//     }
// }

// for_ex();

// function for_ex(){
//     var unames=['ravi','kiran','nanda','kumar','ram','Shyam','xyz'];

//     for(i=0;i<unames.length;i++){
//         console.log(unames[i])
//     }
// }

// for_ex();


// Task
// Display these username in my ui, usig <li> tag


// Task2
// var unames=['ravi','kiran','nanda','kumar','ram','Shyam','xyz'];
// carea an array with usernames starting with 'r' - ['ravi', 'ram']
// remaining all usernames in another array - ['kiran','nanda','kumar','Shyam','xyz'];

