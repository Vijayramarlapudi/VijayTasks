// function if_ex(){
//     a = 3, b=10

//     if(a > b){
//         console.log("a is greater than b")
//     }
// }

// if_ex();

// function if_elseIf_ex(){
//     a = 3, b=10

//     if(a > b){
//         console.log("a is greater than b")
//     }else if(a < b){
//         console.log("a is less than b")
//     }
// }

// if_elseIf_ex();

// function if_elseIf_else_ex(){
//     a = 3, b=3

//     if(a > b){
//         console.log("a is greater than b")
//     }else if(a < b){
//         console.log("a is less than b")
//     }else{
//         console.log("a equals to b") 
//     }
// }

// if_elseIf_else_ex();


// 20/50/90


// function cricketFormat(){
//     var noOvers = 50;

//     if(noOvers==20){
//         console.log("T20 International")
//     }else if(noOvers==50){
//         console.log("One Day International")
//     }else if(noOvers==90){
//         console.log("Test International")
//     }else{
//         console.log("Invalid cricket format")
//     }
// }

// cricketFormat();