// ?:(Conditional Operator)

a = 10
b = 3

console.log((a>b)? "Yes, I know":"not true");
