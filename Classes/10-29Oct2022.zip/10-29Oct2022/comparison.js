// >, <, >=, <=, !=(Not equels to), ==(Value comparison), ===(Type and value comparision), 

// var a = 10;
// var b = 6;

// console.log(a > b)
// console.log(a < b)
// console.log(a >= b)
// console.log(a <= b)
// console.log(a != b)


// a=10, b="10"

// console.log(a==b)
// console.log(a===b)

