// Assignment Operator:

// =, +=, -=, *=, /=, %=

var a=10;

a = a + 10; 

a += 10; 

console.log(a)