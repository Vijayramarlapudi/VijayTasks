var a=10;
var b=30;
var c="20"

// console.log(a+b)
// console.log(a-b)
// console.log(a*b)
// console.log(a/b)
// console.log(a%b)

console.log(a+b+c)
console.log(a+c+b)

// + will be act as arthimetica operator while working with numbers
// it can also be used as concatinate operator to deal with strings