// 20,6
// 10,3

// var var_name=data

var x=10;
var y=3;

console.log(x+y)
console.log(x-y)
console.log(x*3)
console.log(x/y)
console.log(x%y)

// repitative work
// time consumption
// human errors