function f1(){
    var a=100;

    console.log(a)

    var b=200;
    var c=300

    console.log(b);
    console.log(c)
}

console.log(a)

f1();