function f1(){
    console.log(a);
}

var a = 200;

f1();