// Numbers:

// In JS, we can create numbers in 2 ways.
// 1. using primitive type.
// 2. using object

var a =100; // recommended
var b = new Number(100); // not recommended

// console.log(a);
// console.log(b);

// console.log(a == b);
// console.log(a === b);


var b = 20.123;
console.log(b.toExponential(2));
console.log(b.toFixed(2));
console.log(b.toPrecision(2));
console.log(b.toPrecision(3));