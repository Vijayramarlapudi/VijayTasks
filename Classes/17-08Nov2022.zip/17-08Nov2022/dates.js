// Dates:
// JS provides a predefined date object to get the current date from system date.

var date = new Date();

console.log(date.getDate());

console.log(date.getDay());

console.log(date.getMonth());

console.log(date.getFullYear());

console.log(date.getHours());

console.log(date.getMinutes());

console.log(date.getSeconds());

console.log(date.getMilliseconds());

var customDate = new Date(1990,2,12);

console.log(customDate.getFullYear());