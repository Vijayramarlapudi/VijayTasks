// var bank= {
//     name: "icici",
//     ifscode: 'icici087677',
//     location: "madhapur"
// }

//  var customer=Object.create(bank);

//  console.log(customer);

//  customer.username="ravikumar";
//  customer.accno="1234455";
//  customer.balance=9000;

//  console.log(customer);
//  console.log(customer.name);
//  console.log(customer.ifscode);


// var config=Object.freeze( {
//     port:9011,
//     url:"http://www.facebook.com",
//     id:1244
// })

// console.log('config', config);

// config.port=9799;

// console.log('config', config)

// console.log(Object.isFrozen(config));
